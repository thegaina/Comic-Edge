import { gsap } from "gsap";

document.querySelectorAll('.nav-button').forEach(button => {
    button.addEventListener('click', () => {
        // Simple "wave" effect on click
        gsap.to(button, { scale: 1.2, duration: 0.1, yoyo: true, repeat: 1, ease: "power1.out" });

        // You can add more complex wave animation here if desired, e.g., using SVG and GSAP
    });
});

const immersiveModeButton = document.getElementById('immersive-mode-button');
immersiveModeButton.addEventListener('click', () => {
    document.body.classList.toggle('immersive-mode');
});

